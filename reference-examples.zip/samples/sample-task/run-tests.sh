#!/bin/bash
# Run tests
pytest $TEST_DIR/test_outputs.py -v -rA
